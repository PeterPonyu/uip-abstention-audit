The Journal of Chemical Physics source package
Built from the active manuscript source on 23 July 2026.

Build command:
  latexmk -pdf -interaction=nonstopmode -halt-on-error paper_jcp.tex

The compiled manuscript PDF and cover letter are uploaded separately.
This package contains the manuscript source, bibliography, compiled BBL,
and exactly the eight referenced figure PDFs. SHA256SUMS covers every
payload member except SHA256SUMS itself.
